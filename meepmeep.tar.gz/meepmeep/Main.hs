module Main (main) where

main = do
  putStrLn "Meep meep!"
  putStrLn ""